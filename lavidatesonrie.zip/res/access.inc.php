<?php

// Users data
$imSettings['access']['webregistrations_gid'] = 'auktq5rs';
$imSettings['access']['users'] = array(
	'steban_matteus@hotmail.com' => array(
		'groups' => array('2a3ys8ud'),
		'id' => 'o8ex56id',
		'firstname' => 'Admin',
		'lastname' => '',
		'password' => 'asi8w44s',
		'email' => 'steban_matteus@hotmail.com',
		'page' => false
	)
);

// Admins list
$imSettings['access']['admins'] = array('o8ex56id');

// Page/Users permissions
$imSettings['access']['pages'] = array();

// End of file access.inc.php