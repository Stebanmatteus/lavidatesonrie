<div class="float-left box ads-box border-bottom-2 border-mute-light padding-bottom-2">
	<div class="row">
		<img src="<?php echo $image ?>" alt="" class="div-phone center-phone" />
		<div class="text text-light"><?php echo $text ?></div>
	</div>
</div>
