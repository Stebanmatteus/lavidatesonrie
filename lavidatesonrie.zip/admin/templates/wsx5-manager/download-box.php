<div class="float-left box download-box text-light padding-bottom-2">
	<div class="margin-bottom"><?php echo l10n("admin_manager_download", "Download the app from all the main app stores or scan the QR code:") ?></div>
	<img src="images/download-app-qr.png" class="no-phone float-right margin-bottom" alt="">
	<div>
		<a href="http://www.websitex5.com/download/wsx5manager/android"><img class="div-phone center-phone" src="images/google-play-badge-small.png" alt="Google Play Store"></a>
		<a href="http://www.websitex5.com/download/wsx5manager/ios"><img class="div-phone center-phone" src="images/appstore-badge-small.png" alt="App Store" ></a>
	</div>
</div>
