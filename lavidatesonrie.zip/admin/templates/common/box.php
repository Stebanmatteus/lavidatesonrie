<div class="content-box border-left-2 border-color-1 background-white<?php echo isset($cssClass) ? " " . $cssClass : "" ?>">
	<?php echo $content ?>
</div>
