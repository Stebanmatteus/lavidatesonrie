<li>
	<a href="<?php echo $url ?>" class="navbar-link <?php echo $selected ? "selected background-mute" : "" ?>" title="<?php echo $text ?>">
		<img src="<?php echo $image ?>" alt="<?php $text ?>"/>
		<span class="text"><?php echo $text ?></span>
		<span class="flag border-mute-light"></span>
	</a>
</li>
