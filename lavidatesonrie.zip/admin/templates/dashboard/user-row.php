<div class="user text-small">
	<span class="text-semibold"><?php echo $name ?></span>
	<span class="text-light"><?php echo date("d/m/Y", strtotime($timestamp)) ?></span>
	<span class="text-light text-right"><?php echo $ip ?></span>
</div>
