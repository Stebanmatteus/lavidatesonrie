<?php

require_once "../res/x5engine.php";
require_once "libraries/controlpanel.class.php";
